package edu.app.contenido.repo;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class CsvUtil {
  private CsvUtil(){}

  public static List<List<String>> read(Path path) {
    List<List<String>> rows = new ArrayList<>();
    try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
      String line;
      while ((line = br.readLine()) != null) {
        if (line.isBlank() || line.startsWith("#")) continue;
        rows.add(Arrays.asList(line.split(",", -1)));
      }
    } catch (IOException e) {
      throw new UncheckedIOException(e);
    }
    return rows;
  }

  public static void write(Path path, List<List<String>> rows) {
    try (BufferedWriter bw = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
      for (List<String> r : rows) {
        bw.write(String.join(",", r));
        bw.newLine();
      }
    } catch (IOException e) {
      throw new UncheckedIOException(e);
    }
  }
}
