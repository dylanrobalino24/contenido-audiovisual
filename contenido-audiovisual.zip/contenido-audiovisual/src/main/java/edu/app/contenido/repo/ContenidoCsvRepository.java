package edu.app.contenido.repo;

import java.nio.file.Path;
import java.util.*;
import edu.app.contenido.model.Pelicula;

public class ContenidoCsvRepository implements ContenidoRepository {
  private final Path base;

  public ContenidoCsvRepository(Path base) {
    this.base = base;
  }

  @Override
  public List<Pelicula> findAll() {
    var rows = CsvUtil.read(base.resolve("data/peliculas.csv"));
    List<Pelicula> out = new ArrayList<>();
    for (var r : rows) {
      out.add(new Pelicula(
          r.get(0),
          r.get(1),
          Integer.parseInt(r.get(2)),
          Integer.parseInt(r.get(3))
      ));
    }
    return out;
  }

  @Override
  public void save(Pelicula p) {
    var rows = CsvUtil.read(base.resolve("data/peliculas.csv"));
    rows.add(List.of(
        p.getId(),
        p.getTitulo(),
        String.valueOf(p.getAnio()),
        String.valueOf(p.getDuracionMin())
    ));
    CsvUtil.write(base.resolve("data/peliculas.csv"), rows);
  }
}
