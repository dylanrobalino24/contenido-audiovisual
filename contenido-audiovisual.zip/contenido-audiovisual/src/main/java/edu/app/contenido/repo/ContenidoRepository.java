package edu.app.contenido.repo;

import java.util.List;
import edu.app.contenido.model.Pelicula;

public interface ContenidoRepository {
  List<Pelicula> findAll();
  void save(Pelicula p);
}
