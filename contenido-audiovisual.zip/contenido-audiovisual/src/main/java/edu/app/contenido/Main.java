package edu.app.contenido;

import edu.app.contenido.controller.AppController;

public class Main {
    public static void main(String[] args) {
        new AppController().run();
    }
}
