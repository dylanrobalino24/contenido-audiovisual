package edu.app.contenido.controller;

import java.nio.file.Paths;
import java.util.Scanner;
import edu.app.contenido.model.Pelicula;
import edu.app.contenido.repo.ContenidoCsvRepository;
import edu.app.contenido.service.CatalogoService;
import edu.app.contenido.view.ConsoleView;

public class AppController {
    private final CatalogoService service;
    private final ConsoleView view;
    private final Scanner sc = new Scanner(System.in);

    public AppController(){
        var repo = new ContenidoCsvRepository(Paths.get("src/main/resources"));
        this.service = new CatalogoService(repo);
        this.view = new ConsoleView();
    }

    public void run(){
        int opt;
        do {
            view.showMenu();
            try {
                opt = Integer.parseInt(sc.nextLine().trim());
            } catch (Exception e) {
                opt = -1;
            }

            switch (opt) {
                case 1 -> view.showPeliculas(service.listarPeliculas());
                case 2 -> agregarPelicula();
                case 0 -> view.ok("Saliendo…");
                default -> view.error("Opción inválida");
            }
        } while (opt != 0);
    }

    private void agregarPelicula(){
        System.out.print("ID: ");
        String id = sc.nextLine().trim();

        System.out.print("Título: ");
        String titulo = sc.nextLine().trim();

        System.out.print("Año: ");
        int anio = Integer.parseInt(sc.nextLine().trim());

        System.out.print("Duración: ");
        int dur = Integer.parseInt(sc.nextLine().trim());

        service.agregarPelicula(new Pelicula(id, titulo, anio, dur));
        view.ok("Película agregada");
    }
}
