package edu.app.contenido.model;

public class Pelicula extends ContenidoAudiovisual {
    private int duracionMin;

    public Pelicula(String id, String titulo, int anio, int duracionMin) {
        super(id, titulo, anio);
        this.duracionMin = duracionMin;
    }

    public int getDuracionMin() { return duracionMin; }
}
