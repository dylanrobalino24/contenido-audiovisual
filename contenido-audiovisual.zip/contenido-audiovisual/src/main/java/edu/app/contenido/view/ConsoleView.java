package edu.app.contenido.view;

import java.util.List;
import edu.app.contenido.model.Pelicula;

public class ConsoleView {
    public void showMenu(){
        System.out.println("""
            === Contenido Audiovisual ===
            1) Listar Películas
            2) Agregar Película
            0) Salir
        """);
    }

    public void showPeliculas(List<Pelicula> peliculas){
        peliculas.forEach(p ->
            System.out.printf("- %s (%d) [%d min]%n",
                p.getTitulo(), p.getAnio(), p.getDuracionMin())
        );
    }

    public void ok(String msg){
        System.out.println("[OK] " + msg);
    }

    public void error(String msg){
        System.out.println("[ERROR] " + msg);
    }
}
