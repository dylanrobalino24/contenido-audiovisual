package edu.app.contenido.service;

import java.util.List;
import edu.app.contenido.model.Pelicula;
import edu.app.contenido.repo.ContenidoRepository;

public class CatalogoService {
  private final ContenidoRepository repo;

  public CatalogoService(ContenidoRepository repo){ this.repo = repo; }

  public List<Pelicula> listarPeliculas(){ return repo.findAll(); }

  public void agregarPelicula(Pelicula p){ repo.save(p); }
}
